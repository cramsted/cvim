# Setup fzf
# ---------
if [[ ! "$PATH" == */Users/cramstedt/.fzf/bin* ]]; then
  export PATH="${PATH:+${PATH}:}/Users/cramstedt/.fzf/bin"
fi

# Auto-completion
# ---------------
[[ $- == *i* ]] && source "/Users/cramstedt/.fzf/shell/completion.bash" 2> /dev/null

# Key bindings
# ------------
source "/Users/cramstedt/.fzf/shell/key-bindings.bash"
