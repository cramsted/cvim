This is a mirror of http://www.vim.org/scripts/script.php?script_id=3436

This color scheme imitates TextMate theme Twilight.

A screenshot can be viewed here:
http://nealmilstein.com/ext/twilight256.png

The theme is designed to be used on a black background. I only tested it
using a 256-color terminal; I do not think it will work on much else (gvim,
8-color terminal, etc.).

The functions in this theme that convert hex color codes to the nearest
xterm-256 color number are from the theme desert2 (desert256), developed by Henry So, Jr. 

The colors of this theme are based on the TextMate Twilight theme
 www.macromates.com
